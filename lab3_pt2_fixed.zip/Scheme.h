/*

Elias Sims, Section 1, elisims@byu.edu
Lab 3: Relational Database

*/

#ifndef SCHEME_H_
#define SCHEME_H_

#include <vector>
#include <string>

using namespace std;

class Scheme: public vector<string> { };

#endif /* SCHEME_H_ */